// models/Booking.js
const { DataTypes} = require('sequelize');
const db = require('../config/db');
const User = require('./User');


const Booking =db.define('Booking',{
  roomType: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  checkIn: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  checkOut: {
    type: DataTypes.DATE,
    allowNull: false,
  },

});

module.exports = Booking;