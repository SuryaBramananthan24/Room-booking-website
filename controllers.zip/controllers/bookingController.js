const Booking = require('../models/Booking');
const User = require('../models/User');



async function createBooking(req, res) {
    let { roomType, checkIn, checkOut} = req.body;
    //console.log('Creating booking with:',{roomType,checkIn,checkOut});
    Booking.create({ 
	roomType:roomType, 
	checkIn:checkIn, 
	checkOut:checkOut 
        
    })
    .then(booking=>{
     res.redirect('/lastbooking.html');
    })
    .catch (err=> {
    console.error('Error creating booking',error);
    res.status(500).send('Error');
  })
}
async function getBookings(req, res) {
  try {
    const lastBooking = await Booking.findOne({
      order: [['createdAt', 'DESC']],
    });

    if (lastBooking) {
      res.json(lastBooking);
    } else {
      res.status(404).send('No bookings found');
    }
  } catch (error) {
    console.error('Error fetching last booking:', error);
    res.status(500).send('Internal Server Error');
  }
}




module.exports = { createBooking, getBookings };