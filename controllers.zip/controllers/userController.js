// Assuming this is part of your userController.js file

const User = require('../models/User'); // Import your User model

function createlogin(req, res) {
  let { username, password } = req.body; // Assuming username and password are from request body

  // Example of saving user to database
  User.create({
    username: username,
    password: password // You should hash passwords before saving them
  })
  .then(user => {
    // User successfully created, now redirect
    res.redirect('/bookroom.html'); // Redirect to '/bookroom' after successful user creation
  })
  .catch(err => {
    console.error('Database error:', err);
    res.status(500).send('Database error'); // Handle database error
  });
}

module.exports = {
  createlogin
};

