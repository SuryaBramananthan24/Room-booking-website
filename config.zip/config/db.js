// config/db.js
const { Sequelize } = require('sequelize');

const db = new Sequelize( {
  host: 'localhost',
  dialect: 'mysql',
  username: 'root',
  password:'root',
  database:'hotel_db'
});

module.exports = db;